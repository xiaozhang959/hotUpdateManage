// Minimal shim to satisfy TS when importing 'ali-oss'
// Library is used dynamically; concrete typings are unnecessary for current usage.
declare module 'ali-oss';

