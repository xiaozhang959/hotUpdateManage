-- DropIndex
DROP INDEX "Project_createdAt_idx";

-- DropIndex
DROP INDEX "Project_userId_idx";

-- DropIndex
DROP INDEX "SystemConfig_key_category_idx";

-- DropIndex
DROP INDEX "User_createdAt_idx";

-- DropIndex
DROP INDEX "User_role_idx";

-- DropIndex
DROP INDEX "Version_projectId_version_idx";

-- DropIndex
DROP INDEX "Version_projectId_isCurrent_idx";

-- DropIndex
DROP INDEX "Version_createdAt_idx";

-- DropIndex
DROP INDEX "Version_projectId_idx";
